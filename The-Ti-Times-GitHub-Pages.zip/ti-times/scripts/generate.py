"""Daily static edition generator: sourced RSS links, no invented reporting."""
import datetime,json,os,pathlib,urllib.request,xml.etree.ElementTree as ET,html,re
ROOT=pathlib.Path(__file__).resolve().parents[1]
DEST=ROOT/'public'/'editions';DEST.mkdir(parents=True,exist_ok=True)
TODAY=datetime.datetime.now(datetime.timezone.utc).date()
FEEDS=[('CYBER / THREAT INTEL','https://feeds.feedburner.com/TheHackersNews'),('SPACE / ORBIT','https://www.nasa.gov/feed/'),('TECH / SYSTEMS','https://feeds.arstechnica.com/arstechnica/index')]

def fetch_feed(section,url):
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'TheTiTimes/1.0 (+personal-news-reader)'})
  with urllib.request.urlopen(req,timeout=15) as r: root=ET.fromstring(r.read(1_500_000))
  items=root.findall('.//item')
  if not items:
   ns={'a':'http://www.w3.org/2005/Atom'};items=root.findall('.//a:entry',ns)
  for item in items[:5]:
   def val(tag):
    el=item.find(tag)
    return ''.join(el.itertext()).strip() if el is not None else ''
   title=val('title') or val('{http://www.w3.org/2005/Atom}title')
   link=val('link')
   if not link:
    el=item.find('{http://www.w3.org/2005/Atom}link');link=el.attrib.get('href','') if el is not None else ''
   desc=val('description') or val('summary') or val('{http://www.w3.org/2005/Atom}summary')
   desc=re.sub('<[^>]+>',' ',html.unescape(desc));desc=' '.join(desc.split())[:430]
   if title and link.startswith('http'):
    return {'section':section,'title':html.unescape(title),'summary':desc or 'Read the original source for details.','url':link}
 except Exception as exc: print(f'Feed unavailable: {section}: {exc}')
 return None

LESSONS=[
 ('Risk treatment and accountable owners','Security+ 5.0 · CISSP Domain 1','Mitigate, transfer, avoid, and accept are four risk treatment strategies. Controls can reduce probability or impact, but residual risk may remain. Risk acceptance requires an authorized business risk owner, documented rationale, and periodic review. Technical staff assess and advise; business leadership owns the decision.','Security recommends. Business owns the risk.',[{'exam':'SECURITY+','question':'A patch reduces the likelihood of exploitation. Which treatment is this?','options':['Avoidance','Mitigation','Transfer','Acceptance'],'answer':1,'explanation':'Patching is a mitigating control.'},{'exam':'CISSP','question':'A remediation costs more than the expected loss. What is the BEST next step?','options':['Ignore the risk','Have the engineer accept it','Present options to the authorized risk owner','Delete all evidence'],'answer':2,'explanation':'Risk acceptance belongs to an authorized business risk owner.'}]),
 ('Least privilege and identity boundaries','Security+ 2.0 · CISSP Domain 5','Least privilege grants identities only the access needed to complete authorized tasks. Pair it with separation of duties to reduce opportunities for fraud or error. Role-based access control assigns permissions by job function, while attribute-based access control evaluates context such as device, resource, and time. Periodic access reviews help remove accumulated privileges.','Need-to-know is not the same as nice-to-have.',[{'exam':'SECURITY+','question':'Which practice limits permissions to job requirements?','options':['Job rotation','Least privilege','Open access','Implicit trust'],'answer':1,'explanation':'Least privilege limits access to necessary permissions.'},{'exam':'CISSP','question':'A manager requests permanent admin rights for convenience. What is the BEST response?','options':['Grant access immediately','Deny without review','Assess business need and approve time-limited least-privilege access if justified','Share an existing admin password'],'answer':2,'explanation':'Balance business need, authorization, and least privilege.'}]),
 ('Incident response: preserve before changing','Security+ 4.0 · CISSP Domain 7','An incident response plan clarifies preparation, detection, analysis, containment, eradication, and recovery. Evidence handling matters: record who collected what, when, and how, while maintaining chain of custody. In a live incident, responders should follow approved procedures and prioritize safety and business continuity. Do not casually wipe systems before relevant evidence is preserved.','Contain deliberately; preserve evidence.',[{'exam':'SECURITY+','question':'What records evidence handling and transfers?','options':['Service-level agreement','Chain of custody','Asset depreciation','Change freeze'],'answer':1,'explanation':'Chain of custody documents evidence possession and handling.'},{'exam':'CISSP','question':'An infected production host is discovered. What should guide the FIRST response?','options':['Immediately wipe it','Follow the incident response plan and assess impact','Post details publicly','Ignore until maintenance'],'answer':1,'explanation':'Use the approved response process while protecting operations and evidence.'}])]

index_path=DEST/'index.json'
try: existing=json.loads(index_path.read_text())
except:existing=[]
# Only publish a fresh edition if at least one trustworthy feed was fetched.
stories=[x for section,url in FEEDS if (x:=fetch_feed(section,url))]
if not stories:
 print('No feeds available; preserving existing editions rather than fabricating headlines.')
 raise SystemExit(0)
idx=(TODAY.toordinal()%len(LESSONS));title,domain,body,memory,questions=LESSONS[idx]
edition={'date':TODAY.isoformat(),'edition':len(existing)+1,'eyebrow':'TODAY IN SIGNAL, SYSTEMS & LIFE','headline':stories[0]['title'],'dek':'An independently curated morning reading room, built for deliberate attention.','note':'HEADLINES LINK TO THEIR ORIGINAL SOURCES. PERSONAL ITEMS ARE LOCAL, NOT PUBLICLY SYNCED.','stories':stories,'lesson':{'title':title,'domain':domain,'body':body,'memory':memory,'questions':questions},'reflection':'Which decision today will make tomorrow simpler?','puzzle':{'clue':'A record of system activity useful during an investigation (4 letters).','answer':'LOGS','explanation':'Logs are used for monitoring, auditing, and investigations.'},'projects':[]}
(DEST/f'{TODAY}.json').write_text(json.dumps(edition,ensure_ascii=False,indent=2)+'\n')
cutoff=TODAY-datetime.timedelta(days=29)
for path in DEST.glob('????-??-??.json'):
 try:
  if datetime.date.fromisoformat(path.stem)<cutoff:path.unlink()
 except ValueError:pass
new_index=sorted([p.stem for p in DEST.glob('????-??-??.json')],reverse=True)
index_path.write_text(json.dumps(new_index,indent=2)+'\n')
print(f'Published {TODAY}, {len(stories)} sourced stories, {len(new_index)} retained editions.')
